import { ReactNode } from 'react';

import { Container } from './styles';

interface TestProps {
  children: ReactNode;
}

export function Test({ children }: TestProps) {
  return (
    <Container>
      <h1>Test</h1>
      {children}
    </Container>
  );
}

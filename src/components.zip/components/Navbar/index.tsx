import { ReactNode } from 'react';

interface NavbarProps {
  children: ReactNode;
}

export default function Navbar() {
  return (
    <>
      <h1>Navbar</h1>
    </>
  );
}

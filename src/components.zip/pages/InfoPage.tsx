import { invoke } from "@tauri-apps/api/tauri";
import { ReactElement, useRef, useState } from "react";
import { Button } from "react-bootstrap";
import search_logo from '../assets/Search.png';
import profile_logo from '../assets/profilepicture.png';
import menu_logo from '../assets/menu_icon.png';
import ResultList from "../components/searchResult";
import { type AnimeInfo, type Anime } from "../components/searchResult";
import {search} from "../components/searchResult";
import {Routes, Route, useNavigate} from 'react-router-dom';
import "./InfoPage.css";


type ResultListProps = {
    setSearchResult: React.Dispatch<React.SetStateAction<Anime[]>>;
    infoAnime: AnimeInfo;
};

function Search({setSearchResult, infoAnime}: ResultListProps) {
  const [name, setName] = useState("");
  const navigate = useNavigate();


  
    const navigateToSearch = (name: string) => {
        // deconstruct the array to array of Anime objects
        console.log("infoanime", infoAnime);
        setSearchResult([]);
        search(name).then((res: any[]) => {
            const searchResultList: Anime[] = res.map((anime) => {
                const [title, pageurl, imageurl, episode_count, date] = anime;
                return { title, pageurl, imageurl, episode_count, date };
            });
            setSearchResult(searchResultList);
        });
        navigate('/');
    };

  

    return (
        <div>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossOrigin="anonymous"></link>


            <div className="info container-fluid">
                <div className="description row">
                    <img className="col-sm-4" src={infoAnime.imageurl} alt="" />
                    <div className="col-sm-7">
                        <h1>{infoAnime.title}</h1>
                        <h2>Episodes: {infoAnime.episode_count}/{infoAnime.episode_total}</h2>
                        <h2>Genres: {infoAnime.genres}</h2>
                        <h2>Release date: {infoAnime.date}</h2>
                        <h3>{infoAnime.description}</h3>
                    </div>
                </div>
            </div>
            <div className="watch container-fluid">
                <h1>Continue watching at Episode 2046{}</h1>
            </div>
            <div className="container-fluid">
                <div className="episodes row">
                    {infoAnime.episodes.map((anime) => (
                        <div key={anime.link} className="result-info col-sm-4" onClick={() => { }}>
                            <div>
                                <h1>{anime.title}</h1>
                                <div className="progress"><hr /></div>
                                <h2>{anime.date}</h2>
                            </div>
                        </div>
                    ))}
                </div>
            </div>


        </div>
    );
}

export default Search;
